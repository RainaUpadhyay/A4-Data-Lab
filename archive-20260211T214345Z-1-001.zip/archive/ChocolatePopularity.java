import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.List;

import javax.swing.*;
import java.awt.*;

/**
 * Question:
 * What is the most popular chocolate from 2022 to 2025?
 *
 * Popularity = TOTAL BOXES SHIPPED (2022–2025 inclusive)
 *
 * Graph: bar chart (Swing)
 */
public class ChocolatePopularity {

    // 1) Store the raw rows as objects (like "model one entry" requirement)
    static ArrayList<ChocolateSaleEntry> sales = new ArrayList<>();

    // 2) Store totals by product (processing results)
    static Map<String, Integer> boxesByProduct = new HashMap<>();

    // Show top N bars on chart
    static final int TOP_N = 8;

    public static void main(String[] args) {
        // Default file name
        String fileName = (args.length > 0) ? args[0] : "Chocolate Sales (2).csv";
        
        System.out.println("Reading data from: " + fileName);
        
        boolean success = readChocolateSales(fileName);
        
        if (!success) {
            System.err.println("Failed to read data. Exiting.");
            System.exit(1);
        }
        
        if (sales.isEmpty()) {
            System.err.println("No data loaded. Exiting.");
            System.exit(1);
        }
        
        calculateBoxesByProduct(2022, 2025);

        // Find the most popular
        String topProduct = findTopProduct();
        
        if (topProduct == null) {
            System.err.println("No data found for the specified period.");
            System.exit(1);
        }
        
        int topBoxes = boxesByProduct.get(topProduct);

        System.out.println("===============================================");
        System.out.println("Most popular chocolate (2022–2025) by Boxes Shipped:");
        System.out.println("Product: " + topProduct);
        System.out.println("Total Boxes Shipped: " + topBoxes);
        System.out.println("===============================================");

        // Create sorted top list for chart
        List<Map.Entry<String, Integer>> topList = getTopN(boxesByProduct, TOP_N);
        
        if (topList.isEmpty()) {
            System.err.println("No data to display in chart.");
            System.exit(1);
        }

        // Show bar chart window on EDT
        SwingUtilities.invokeLater(() -> {
            showBarChart(topList, "Top " + TOP_N + " Chocolates by Boxes Shipped (2022–2025)");
        });
    }

    // ---------------------- Step 1: Read CSV ----------------------

    public static boolean readChocolateSales(String fileName) {
        // Try multiple date formats
        DateTimeFormatter[] dateFormatters = {
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("MM/dd/yyyy")
        };
        
        int lineCount = 0;
        int errorCount = 0;
        
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String header = br.readLine(); // skip header
            if (header == null) {
                System.out.println("CSV file is empty.");
                return false;
            }
            
            System.out.println("Header: " + header);

            String line;
            while ((line = br.readLine()) != null) {
                lineCount++;
                if (line.trim().isEmpty()) continue; // Skip empty lines
                
                List<String> fields = parseCsvLine(line);

                // Expected columns: Sales Person, Country, Product, Date, Amount, Boxes Shipped
                if (fields.size() != 6) {
                    System.err.println("Warning: Line " + lineCount + " has " + fields.size() + " fields, expected 6. Skipping.");
                    errorCount++;
                    continue;
                }

                try {
                    String salesPerson = fields.get(0).trim();
                    String country = fields.get(1).trim();
                    String product = fields.get(2).trim();
                    
                    // Parse date with multiple format attempts
                    String dateStr = fields.get(3).trim();
                    LocalDate date = null;
                    for (DateTimeFormatter fmt : dateFormatters) {
                        try {
                            date = LocalDate.parse(dateStr, fmt);
                            break;
                        } catch (DateTimeParseException e) {
                            // Try next format
                        }
                    }
                    
                    if (date == null) {
                        System.err.println("Warning: Could not parse date '" + dateStr + "' on line " + lineCount + ". Skipping.");
                        errorCount++;
                        continue;
                    }
                    
                    double amount = parseMoney(fields.get(4));
                    int boxes = parseInteger(fields.get(5).trim());
                    
                    if (boxes < 0) {
                        System.err.println("Warning: Negative boxes on line " + lineCount + ". Skipping.");
                        errorCount++;
                        continue;
                    }

                    sales.add(new ChocolateSaleEntry(salesPerson, country, product, date, amount, boxes));
                    
                } catch (Exception e) {
                    System.err.println("Error processing line " + lineCount + ": " + e.getMessage());
                    errorCount++;
                }
            }
            
            System.out.println("Loaded " + sales.size() + " valid records out of " + lineCount + " lines.");
            if (errorCount > 0) {
                System.out.println("Encountered " + errorCount + " errors during loading.");
            }
            return true;
            
        } catch (FileNotFoundException e) {
            System.err.println("Error: File not found: " + fileName);
            System.err.println("Current directory: " + System.getProperty("user.dir"));
            return false;
        } catch (Exception e) {
            System.err.println("Error reading file: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Handles commas inside quotes (ex: "$5,320.00")
    private static List<String> parseCsvLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                fields.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        fields.add(current.toString());
        return fields;
    }

    private static double parseMoney(String money) {
        String cleaned = money.trim().replace("\"", "").replace("$", "").replace(",", "");
        if (cleaned.isEmpty()) return 0.0;
        return Double.parseDouble(cleaned);
    }
    
    private static int parseInteger(String str) {
        try {
            return Integer.parseInt(str.trim().replace(",", ""));
        } catch (NumberFormatException e) {
            // Try parsing as double first, then convert to int
            try {
                String cleaned = str.trim().replace(",", "");
                return (int) Double.parseDouble(cleaned);
            } catch (NumberFormatException e2) {
                System.err.println("Warning: Cannot parse integer from '" + str + "'. Using 0.");
                return 0;
            }
        }
    }

    // ---------------------- Step 2: Process Data ----------------------

    public static void calculateBoxesByProduct(int startYear, int endYear) {
        boxesByProduct.clear();

        for (ChocolateSaleEntry entry : sales) {
            int year = entry.getDate().getYear();
            if (year >= startYear && year <= endYear) {
                String product = entry.getProduct();
                int boxes = entry.getBoxesShipped();

                boxesByProduct.put(product, boxesByProduct.getOrDefault(product, 0) + boxes);
            }
        }
        
        System.out.println("Processed data for " + boxesByProduct.size() + " products.");
    }

    public static String findTopProduct() {
        if (boxesByProduct.isEmpty()) return null;
        
        String best = null;
        int bestValue = -1;

        for (Map.Entry<String, Integer> entry : boxesByProduct.entrySet()) {
            String product = entry.getKey();
            int total = entry.getValue();
            if (total > bestValue) {
                bestValue = total;
                best = product;
            }
        }
        return best;
    }

    private static List<Map.Entry<String, Integer>> getTopN(Map<String, Integer> map, int n) {
        List<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        
        if (list.isEmpty()) {
            return list;
        }
        
        return list.subList(0, Math.min(n, list.size()));
    }

    // ---------------------- Step 3: Graph (Swing Bar Chart) ----------------------

    public static void showBarChart(List<Map.Entry<String, Integer>> data, String title) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(null);

        frame.add(new BarChartPanel(data));
        frame.setVisible(true);
    }

    // Panel that draws bars
    static class BarChartPanel extends JPanel {
        private final List<Map.Entry<String, Integer>> data;

        public BarChartPanel(List<Map.Entry<String, Integer>> data) {
            this.data = data;
            setBackground(Color.WHITE);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            try {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                int leftMargin = 60;
                int rightMargin = 20;
                int topMargin = 40;
                int bottomMargin = 80;

                if (data == null || data.isEmpty()) {
                    g2.drawString("No data to display", w/2 - 50, h/2);
                    return;
                }

                // Find max value for scaling
                int max = 1;
                for (Map.Entry<String, Integer> e : data) {
                    if (e.getValue() > max) max = e.getValue();
                }

                // Draw axes
                g2.setColor(Color.BLACK);
                g2.drawLine(leftMargin, h - bottomMargin, w - rightMargin, h - bottomMargin); // x-axis
                g2.drawLine(leftMargin, topMargin, leftMargin, h - bottomMargin); // y-axis

                // Draw y-axis labels
                g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
                int numYLabels = 10;
                for (int i = 0; i <= numYLabels; i++) {
                    int value = max * i / numYLabels;
                    int y = h - bottomMargin - (i * (h - topMargin - bottomMargin) / numYLabels);
                    g2.drawString(String.format("%,d", value), leftMargin - 40, y + 5);
                    g2.drawLine(leftMargin - 5, y, leftMargin, y); // tick marks
                }

                int barAreaWidth = (w - leftMargin - rightMargin);
                int barWidth = Math.max(30, barAreaWidth / data.size());
                int barMaxHeight = (h - topMargin - bottomMargin);

                // Title
                g2.setFont(new Font("SansSerif", Font.BOLD, 16));
                g2.drawString("Boxes Shipped (2022–2025)", w/2 - 100, 25);

                // Bars
                g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
                
                // Create colors for bars
                Color[] barColors = {
                    new Color(70, 130, 180),    // Steel Blue
                    new Color(220, 20, 60),     // Crimson
                    new Color(34, 139, 34),     // Forest Green
                    new Color(255, 140, 0),     // Dark Orange
                    new Color(138, 43, 226),    // Blue Violet
                    new Color(255, 69, 0),      // Red-Orange
                    new Color(0, 128, 128),     // Teal
                    new Color(218, 112, 214)    // Orchid
                };

                for (int i = 0; i < data.size(); i++) {
                    String label = data.get(i).getKey();
                    int value = data.get(i).getValue();

                    int barHeight = (int) ((value / (double) max) * barMaxHeight);

                    int x = leftMargin + i * barWidth + 10;
                    int y = (h - bottomMargin) - barHeight;

                    // Set color for this bar
                    g2.setColor(barColors[i % barColors.length]);
                    g2.fillRect(x, y, barWidth - 20, barHeight);
                    
                    // Draw border around bar
                    g2.setColor(Color.BLACK);
                    g2.drawRect(x, y, barWidth - 20, barHeight);

                    // value text on top of bar
                    g2.setColor(Color.BLACK);
                    String valueStr = String.format("%,d", value);
                    int textWidth = g2.getFontMetrics().stringWidth(valueStr);
                    g2.drawString(valueStr, x + (barWidth - 20 - textWidth)/2, y - 5);

                    // rotated-ish label (simple: shorten label)
                    String shortLabel = shorten(label, 14);
                    textWidth = g2.getFontMetrics().stringWidth(shortLabel);
                    g2.drawString(shortLabel, x + (barWidth - 20 - textWidth)/2, h - bottomMargin + 20);
                }
            } catch (Exception e) {
                System.err.println("Error drawing chart: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private String shorten(String s, int maxLen) {
            if (s == null) return "";
            if (s.length() <= maxLen) return s;
            return s.substring(0, maxLen - 3) + "...";
        }
    }
}

/**
 * Models one row in the CSV.
 */
class ChocolateSaleEntry {
    private String salesPerson;
    private String country;
    private String product;
    private LocalDate date;
    private double amount;
    private int boxesShipped;

    public ChocolateSaleEntry(String salesPerson, String country, String product,
                              LocalDate date, double amount, int boxesShipped) {
        this.salesPerson = salesPerson;
        this.country = country;
        this.product = product;
        this.date = date;
        this.amount = amount;
        this.boxesShipped = boxesShipped;
    }

    public String getSalesPerson() { return salesPerson; }
    public String getCountry() { return country; }
    public String getProduct() { return product; }
    public LocalDate getDate() { return date; }
    public double getAmount() { return amount; }
    public int getBoxesShipped() { return boxesShipped; }
    
    @Override
    public String toString() {
        return "ChocolateSaleEntry{" +
               "product='" + product + '\'' +
               ", date=" + date +
               ", boxesShipped=" + boxesShipped +
               '}';
    }
}